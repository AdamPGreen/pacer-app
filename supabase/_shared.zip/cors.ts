export const corsHeaders = {
  'Access-Control-Allow-Origin': '*', // In production, replace with your Vercel URL
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
} 